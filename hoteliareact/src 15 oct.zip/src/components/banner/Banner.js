import "./Banner.css";
function Banner(){
    return(
        <div className="bodyin">
        <section id="banner">
            <h4 id="h4banner">Lorem ipsum dolor sit ameliter,<br/>
            consectetur adipiscing elit</h4>
        </section>
        </div>
    );
}

export default Banner;