import './Registrar.css';
import Barra from '../../components/barra/Barra.js';
import Datos from '../../components/datos/Datos.js';

function Registrar() {
  return (
    <div className="bodyreg">
     <Barra />
     <Datos/>
    </div>

  );
}

export default Registrar;