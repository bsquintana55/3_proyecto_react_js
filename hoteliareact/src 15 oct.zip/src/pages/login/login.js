
import Login from '../../components/login/Login';


function Inicio() {
    return(
        <div>   
            <Login/>
        </div>
    );
    
}

export default Inicio;


