

import err from '../error/Error404.png';
import  '../error/error.css'
function Error404() {
    return(
      

     
    <div class="bodyerror"> 
       
       <h1 error404></h1>
        
      </div>
    );
    

}

export default Error404;