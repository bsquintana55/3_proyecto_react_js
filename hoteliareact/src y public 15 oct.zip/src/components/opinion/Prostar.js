
function Estrella({stall}) {

    return(

        <article>
            <i className={stall? "fa-solid fa-star":"fa-regular fa-star"}></i>
        </article>

    );
    
}

export default Estrella;