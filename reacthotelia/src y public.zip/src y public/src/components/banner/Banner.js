import "./Banner.css";
function Banner(){
    return(
        <section id="banner">
            <h4>Lorem ipsum dolor sit ameliter,<br/>
            consectetur adipiscing elit</h4>
        </section>
    );
}

export default Banner;