 
 function Foto({foto}) {

    return(

        <article>
            <img src={foto}  />
        </article>

    );
    
 }
 export default Foto;