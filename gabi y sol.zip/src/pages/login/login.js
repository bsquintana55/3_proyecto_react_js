
import Login from '../../components/login/Login';


function Inicio() {
    return(
        <section>   
            <Login/>
        </section>
    );
    
}

export default Inicio;


