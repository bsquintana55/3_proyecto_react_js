
function Nombre({nom}) {

    return(

        <article>
            <h5>{nom}</h5>
        </article>

    );
    
}

export default Nombre;