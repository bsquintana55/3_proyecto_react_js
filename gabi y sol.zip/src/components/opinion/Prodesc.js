
function Desc({descripcion}) {

    return(

        <article>
            <p>{descripcion}</p>
        </article>

    );
    
}

export default Desc;